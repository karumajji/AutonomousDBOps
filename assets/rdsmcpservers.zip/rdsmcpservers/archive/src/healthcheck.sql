-- Top 20 Largest Tables ( by disk size )
SELECT
    schemaname AS schema_name,
    tablename AS table_name,
    pg_size_pretty(total_bytes) AS total_size,
    pg_size_pretty(table_bytes) AS table_size,
    pg_size_pretty(index_bytes) AS index_size,
    pg_size_pretty(COALESCE(toast_bytes, 0)) AS toast_size
FROM (
    SELECT *,
           total_bytes - index_bytes - COALESCE(toast_bytes, 0) AS table_bytes
    FROM (
           SELECT c.oid,
                  nspname AS schemaname,
                  relname AS tablename,
                  pg_total_relation_size(c.oid) AS total_bytes,
                  pg_indexes_size(c.oid) AS index_bytes,
                  pg_total_relation_size(c.reltoastrelid) AS toast_bytes
           FROM pg_class c
                    LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
           WHERE c.relkind = 'r'
             AND n.nspname NOT IN ('information_schema', 'pg_catalog')
       ) a
) a
ORDER BY total_bytes DESC
LIMIT 20;

-- Identifying Duplicate Indexes

SELECT
    indrelid::regclass AS "Associated Table Name"
    ,array_agg(indexrelid::regclass) AS "Duplicate Indexe Name"
FROM pg_index
GROUP BY
    indrelid
    ,indkey
HAVING COUNT(*) > 1;

-- Identifying Unused Indexes

SELECT schemaname,
       relname AS table_name,
       indexrelname AS index_name,
       pg_size_pretty(pg_relation_size(i.indexrelid)) AS index_size,
       idx_scan AS index_scans
FROM pg_stat_user_indexes ui
         JOIN pg_index i ON ui.indexrelid = i.indexrelid
WHERE idx_scan < 1
  AND pg_relation_size(i.indexrelid) > 10240
ORDER BY pg_relation_size(i.indexrelid) DESC;

-- Identifying Bloat in Tables

WITH constants AS (
    SELECT current_setting('block_size')::numeric AS bs, 23 AS hdr, 8 AS ma
),
no_stats AS (
    SELECT table_schema, table_name,
        n_live_tup::numeric as est_rows,
        pg_table_size(relid)::numeric as table_size
    FROM information_schema.columns
        JOIN pg_stat_user_tables as psut
           ON table_schema = psut.schemaname
           AND table_name = psut.relname
        LEFT OUTER JOIN pg_stats
        ON table_schema = pg_stats.schemaname
            AND table_name = pg_stats.tablename
            AND column_name = attname
    WHERE attname IS NULL
        AND table_schema NOT IN ('pg_catalog', 'information_schema')
    GROUP BY table_schema, table_name, relid, n_live_tup
),
null_headers AS (
    SELECT
        hdr+1+(sum(case when null_frac <> 0 THEN 1 else 0 END)/8) as nullhdr,
        SUM((1-null_frac)*avg_width) as datawidth,
        MAX(null_frac) as maxfracsum,
        schemaname,
        tablename,
        hdr, ma, bs
    FROM pg_stats CROSS JOIN constants
        LEFT OUTER JOIN no_stats
            ON schemaname = no_stats.table_schema
            AND tablename = no_stats.table_name
    WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
        AND no_stats.table_name IS NULL
        AND EXISTS ( SELECT 1
            FROM information_schema.columns
                WHERE schemaname = columns.table_schema
                    AND tablename = columns.table_name )
    GROUP BY schemaname, tablename, hdr, ma, bs
),
data_headers AS (
    SELECT
        ma, bs, hdr, schemaname, tablename,
        (datawidth+(hdr+ma-(case when hdr%ma=0 THEN ma ELSE hdr%ma END)))::numeric AS datahdr,
        (maxfracsum*(nullhdr+ma-(case when nullhdr%ma=0 THEN ma ELSE nullhdr%ma END))) AS nullhdr2
    FROM null_headers
),
table_estimates AS (
    SELECT schemaname, tablename, bs,
        reltuples::numeric as est_rows, relpages * bs as table_bytes,
    CEIL((reltuples*
            (datahdr + nullhdr2 + 4 + ma -
                (CASE WHEN datahdr%ma=0
                    THEN ma ELSE datahdr%ma END)
                )/(bs-20))) * bs AS expected_bytes,
        reltoastrelid
    FROM data_headers
        JOIN pg_class ON tablename = relname
        JOIN pg_namespace ON relnamespace = pg_namespace.oid
            AND schemaname = nspname
    WHERE pg_class.relkind = 'r'
),
estimates_with_toast AS (
    SELECT schemaname, tablename,
        TRUE as can_estimate,
        est_rows,
        table_bytes + ( coalesce(toast.relpages, 0) * bs ) as table_bytes,
        expected_bytes + ( ceil( coalesce(toast.reltuples, 0) / 4 ) * bs ) as expected_bytes
    FROM table_estimates LEFT OUTER JOIN pg_class as toast
        ON table_estimates.reltoastrelid = toast.oid
            AND toast.relkind = 't'
),
table_estimates_plus AS (
    SELECT current_database() as databasename,
            schemaname, tablename, can_estimate,
            est_rows,
            CASE WHEN table_bytes > 0
                THEN table_bytes::NUMERIC
                ELSE NULL::NUMERIC END
                AS table_bytes,
            CASE WHEN expected_bytes > 0
                THEN expected_bytes::NUMERIC
                ELSE NULL::NUMERIC END
                    AS expected_bytes,
            CASE WHEN expected_bytes > 0 AND table_bytes > 0
                AND expected_bytes <= table_bytes
                THEN (table_bytes - expected_bytes)::NUMERIC
                ELSE 0::NUMERIC END AS bloat_bytes
    FROM estimates_with_toast
    UNION ALL
    SELECT current_database() as databasename,
        table_schema, table_name, FALSE,
        est_rows, table_size,
        NULL::NUMERIC, NULL::NUMERIC
    FROM no_stats
),
bloat_data AS (
    SELECT current_database() as databasename,
        schemaname, tablename, can_estimate,
        table_bytes, round(table_bytes/(1024^2)::NUMERIC,3) as table_mb,
        expected_bytes, round(expected_bytes/(1024^2)::NUMERIC,3) as expected_mb,
        round(bloat_bytes*100/table_bytes) as pct_bloat,
        round(bloat_bytes/(1024::NUMERIC^2),2) as mb_bloat,
        table_bytes, expected_bytes, est_rows
    FROM table_estimates_plus
)
SELECT databasename, schemaname, tablename,
    can_estimate,
    est_rows,
    pct_bloat, mb_bloat,
    table_mb
FROM bloat_data
WHERE ( pct_bloat >= 50 AND mb_bloat >= 20 )
    OR ( pct_bloat >= 25 AND mb_bloat >= 1000 )
ORDER BY pct_bloat DESC;

-- Identifying Bloat in Indexes

WITH index_stats AS (
    SELECT
        current_database() AS database_name,
        ns.nspname AS schema_name,
        ic.relname AS index_name,
        pg_size_pretty(pg_relation_size(ic.oid)) AS index_size,
        pg_relation_size(ic.oid) AS index_size_bytes,
        idx.indisunique AS is_unique,
        idx.indisprimary AS is_primary,
        COALESCE(NULLIF(pg_stat_user_indexes.idx_tup_read, 0), 0) AS estimated_row_count,
        (pg_relation_size(ic.oid)::bigint -
         COALESCE(
             NULLIF(pg_stat_user_indexes.idx_tup_read::bigint, 0) *
             NULLIF(pg_stat_user_indexes.idx_scan::bigint, 1),
             0
         )::bigint) AS estimated_bloat_bytes
    FROM pg_class ic
    JOIN pg_namespace ns ON ic.relnamespace = ns.oid
    JOIN pg_index idx ON ic.oid = idx.indexrelid
    JOIN pg_stat_user_indexes ON ic.oid = pg_stat_user_indexes.indexrelid
    WHERE ic.relkind = 'i'
      AND ns.nspname NOT IN ('information_schema', 'pg_catalog', 'pg_toast')
),
index_bloat AS (
    SELECT
        database_name,
        schema_name,
        index_name,
        CASE
            WHEN index_size_bytes > estimated_bloat_bytes THEN 'y'
            ELSE 'n'
        END AS can_estimate_bloat,
        estimated_row_count,
        pg_size_pretty(GREATEST(estimated_bloat_bytes, 0)) AS index_bloat_size,
        ROUND(
            100 *
            GREATEST(estimated_bloat_bytes::numeric, 0) / NULLIF(index_size_bytes::numeric, 0),
            2
        ) AS index_bloat_percent,
        pg_size_pretty(index_size_bytes) AS index_size
    FROM index_stats
)
SELECT
    database_name,
    schema_name,
    index_name,
    can_estimate_bloat,
    estimated_row_count,
    index_bloat_percent,
    index_bloat_size,
    index_size
FROM index_bloat
WHERE can_estimate_bloat='y'
ORDER BY schema_name, index_name;